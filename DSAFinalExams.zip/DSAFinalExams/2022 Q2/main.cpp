#include <iostream>
#include "BST.h"

using namespace std;

int main() {
    BST bst;
    int choice, element, low, high;
    do {
        cout << "1. Insert Element" << endl;
        cout << "2. Print BST elements in given range(recursively)" << endl;
        cout << "3. Print in-order" << endl;
        cout << "4. Quit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter element to insert: ";
                cin >> element;
                bst.insertElement(element);
                break;
            case 2:
                cout << "Enter range (low high): ";
                cin >> low >> high;
                cout << "BST elements in range: ";
                bst.printRange(low, high);
                break;
            case 3:
                cout << "In-order traversal: ";
                bst.inOrder();
                break;
            case 4:
                cout << "Exiting..." << endl;
                break;
            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 4);

    return 0;
}
