#ifndef BST_H
#define BST_H

class Node {
public:
    int data;
    Node* left;
    Node* right;
    Node(int val);
};

class BST {
private:
    Node* root;
    void insertUtil(Node* node, int key);
    void printRangeUtil(Node* node, int low, int high);
    void inOrderUtil(Node* node);
public:
    BST();
    void insertElement(int key);
    void printRange(int low, int high);
    void inOrder();
};

#endif // BST_H
