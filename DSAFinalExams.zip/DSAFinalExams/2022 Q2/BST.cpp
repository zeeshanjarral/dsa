#include "BST.h"
#include <iostream>

Node::Node(int val) {
    data = val;
    left = nullptr;
    right = nullptr;
}

BST::BST() {
    root = nullptr;
}

void BST::insertUtil(Node* node, int key) {
    if (key < node->data) {
        if (node->left == nullptr) {
            node->left = new Node(key);
        } else {
            insertUtil(node->left, key);
        }
    } else {
        if (node->right == nullptr) {
            node->right = new Node(key);
        } else {
            insertUtil(node->right, key);
        }
    }
}

void BST::insertElement(int key) {
    if (root == nullptr) {
        root = new Node(key);
    } else {
        insertUtil(root, key);
    }
}

void BST::printRangeUtil(Node* node, int low, int high) {
    if (node == nullptr)
        return;
    if (node->data > low)
        printRangeUtil(node->left, low, high);
    if (node->data >= low && node->data <= high)
        std::cout << node->data << " ";
    if (node->data < high)
        printRangeUtil(node->right, low, high);
}

void BST::printRange(int low, int high) {
    printRangeUtil(root, low, high);
    std::cout << std::endl;
}

void BST::inOrderUtil(Node* node) {
    if (node == nullptr)
        return;
    inOrderUtil(node->left);
    std::cout << node->data << " ";
    inOrderUtil(node->right);
}

void BST::inOrder() {
    inOrderUtil(root);
    std::cout << std::endl;
}
