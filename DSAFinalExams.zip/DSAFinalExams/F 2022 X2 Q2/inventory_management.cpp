// inventory_management.cpp
#include "inventory_management.h"

InventoryManager::InventoryManager() : root(nullptr) {}

InventoryManager::~InventoryManager() {
    // Perform post-order traversal and delete nodes
    // Not implemented in this example for simplicity
}

void InventoryManager::insert(TreeNode*& node, int item) {
    if (node == nullptr) {
        node = new TreeNode(item);
    } else {
        if (item < node->key) {
            insert(node->left, item);
        } else {
            insert(node->right, item);
        }
    }
}

void InventoryManager::addItem(int item) {
    insert(root, item);
}

void InventoryManager::displayDescending(TreeNode* node) const {
    if (node == nullptr) {
        return;
    }
    displayDescending(node->right);
    std::cout << node->key << " ";
    displayDescending(node->left);
}

void InventoryManager::displayInventory() const {
    std::cout << "Inventory Items (Descending Order): ";
    displayDescending(root);
    std::cout << std::endl;
}

bool InventoryManager::search(TreeNode* node, int item) const {
    if (node == nullptr) {
        return false;
    }
    if (node->key == item) {
        return true;
    } else if (item < node->key) {
        return search(node->left, item);
    } else {
        return search(node->right, item);
    }
}

bool InventoryManager::searchItem(int item) const {
    return search(root, item);
}
