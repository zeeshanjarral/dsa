// inventory_management.h
#ifndef INVENTORY_MANAGEMENT_H
#define INVENTORY_MANAGEMENT_H

#include <iostream>

class TreeNode {
public:
    int key;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int item) : key(item), left(nullptr), right(nullptr) {}
};

class InventoryManager {
private:
    TreeNode* root;

    void insert(TreeNode*& node, int item);
    void displayDescending(TreeNode* node) const;
    bool search(TreeNode* node, int item) const;

public:
    InventoryManager();
    ~InventoryManager();

    void addItem(int item);
    void displayInventory() const;
    bool searchItem(int item) const;
};

#endif // INVENTORY_MANAGEMENT_H
