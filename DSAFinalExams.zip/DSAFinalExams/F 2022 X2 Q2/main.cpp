// main.cpp
#include <iostream>
#include "inventory_management.h"

int main() {
    InventoryManager inventory;

    // Adding items to inventory
    inventory.addItem(50);
    inventory.addItem(30);
    inventory.addItem(70);
    inventory.addItem(20);
    inventory.addItem(40);
    inventory.addItem(60);
    inventory.addItem(80);

    // Displaying inventory in descending order
    inventory.displayInventory();

    // Searching for an item
    int itemToSearch = 40;
    if (inventory.searchItem(itemToSearch)) {
        std::cout << "Item " << itemToSearch << " found in the inventory." << std::endl;
    } else {
        std::cout << "Item " << itemToSearch << " not found in the inventory." << std::endl;
    }

    return 0;
}
