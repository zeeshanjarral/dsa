#ifndef DOUBLYLINKEDLIST_H
#define DOUBLYLINKEDLIST_H

class Node {
public:
    int data;
    Node* next;
    Node* prev;
    Node(int val);
};

class DoublyLinkedList {
private:
    Node* head;
public:
    DoublyLinkedList();
    void insertElement(int val);
    void printList();
    int findMax();
    int findMin();
};

#endif // DOUBLYLINKEDLIST_H
