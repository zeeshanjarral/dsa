#include <iostream>
#include "DoublyLinkedList.h"

using namespace std;

int main() {
    DoublyLinkedList list;
    int choice, element;
    do {
        cout << "1. Insert Element" << endl;
        cout << "2. Print doubly linked list" << endl;
        cout << "3. Print maximum value" << endl;
        cout << "4. Print minimum value" << endl;
        cout << "5. Quit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter element to insert: ";
                cin >> element;
                list.insertElement(element);
                break;
            case 2:
                cout << "Doubly linked list: ";
                list.printList();
                break;
            case 3:
                cout << "Maximum value: " << list.findMax() << endl;
                break;
            case 4:
                cout << "Minimum value: " << list.findMin() << endl;
                break;
            case 5:
                cout << "Exiting..." << endl;
                break;
            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 5);

    return 0;
}
