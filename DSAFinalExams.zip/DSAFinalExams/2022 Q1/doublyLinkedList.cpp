#include "DoublyLinkedList.h"
#include <iostream>

Node::Node(int val) {
    data = val;
    next = nullptr;
    prev = nullptr;
}

DoublyLinkedList::DoublyLinkedList() {
    head = nullptr;
}

void DoublyLinkedList::insertElement(int val) {
    Node* newNode = new Node(val);
    if (head == nullptr) {
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->prev = temp;
    }
}

void DoublyLinkedList::printList() {
    Node* temp = head;
    while (temp != nullptr) {
        std::cout << temp->data << " -> ";
        temp = temp->next;
    }
    std::cout << "NULL" << std::endl;
}

int max(int a, int b) {
    return (a > b) ? a : b;
}

int min(int a, int b) {
    return (a < b) ? a : b;
}

int findMaxUtil(Node* node) {
    if (node == nullptr)
        return INT_MIN;
    return max(node->data, findMaxUtil(node->next));
}

int findMinUtil(Node* node) {
    if (node == nullptr)
        return INT_MAX;
    return min(node->data, findMinUtil(node->next));
}

int DoublyLinkedList::findMax() {
    return findMaxUtil(head);
}

int DoublyLinkedList::findMin() {
    return findMinUtil(head);
}
