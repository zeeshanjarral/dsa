#include "catering.h"

void CateringService::insertEvent(int orderID, const std::string& eventName) {
    orderMap[orderID] = eventName;
}

void CateringService::deleteEvent(int orderID) {
    orderMap.erase(orderID);
}

void CateringService::printAllOrders() {
    std::cout << "Order ID\tEvent Name\n";
    for (const auto& entry : orderMap) {
        std::cout << entry.first << "\t\t" << entry.second << std::endl;
    }
}
