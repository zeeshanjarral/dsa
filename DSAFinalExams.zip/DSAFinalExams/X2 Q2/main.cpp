#include <iostream>
#include "catering.h"

using namespace std;

int main() {
    CateringService cateringService;
    int choice, orderID;
    string eventName;

    do {
        cout << "\nMenu:\n";
        cout << "1. Insert a new event\n";
        cout << "2. Delete an event\n";
        cout << "3. Print all orders\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                cout << "Enter order ID: ";
                cin >> orderID;
                cout << "Enter event name: ";
                cin >> eventName;
                cateringService.insertEvent(orderID, eventName);
                break;
            case 2:
                cout << "Enter order ID to delete: ";
                cin >> orderID;
                cateringService.deleteEvent(orderID);
                break;
            case 3:
                cateringService.printAllOrders();
                break;
            case 4:
                cout << "Exiting program...\n";
                break;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while(choice != 4);

    return 0;
}
