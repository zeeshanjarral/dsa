#ifndef CATERING_H
#define CATERING_H

#include <iostream>
#include <unordered_map>

class CateringService {
private:
    std::unordered_map<int, std::string> orderMap;

public:
    void insertEvent(int orderID, const std::string& eventName);
    void deleteEvent(int orderID);
    void printAllOrders();
};

#endif // CATERING_H
