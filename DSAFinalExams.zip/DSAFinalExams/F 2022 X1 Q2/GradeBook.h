#ifndef GRADEBOOK_H
#define GRADEBOOK_H

#include <iostream>
#include <unordered_map>

class GradeBook {
private:
    std::unordered_map<std::string, int> gradebookMap;

public:
    // Function to insert a new student and their total test score into the gradebook
    void insertStudent(const std::string& name, int score);

    // Function to delete a student and their total test score from the gradebook
    void deleteStudent(const std::string& name);

    // Function to print the entire gradebook
    void printGradebook() const;
};

#endif
