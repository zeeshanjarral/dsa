#include "GradeBook.h"

// Function to insert a new student and their total test score into the gradebook
void GradeBook::insertStudent(const std::string& name, int score) {
    gradebookMap[name] = score;
}

// Function to delete a student and their total test score from the gradebook
void GradeBook::deleteStudent(const std::string& name) {
    auto it = gradebookMap.find(name);
    if (it != gradebookMap.end()) {
        gradebookMap.erase(it);
        std::cout << "Student " << name << " deleted from the gradebook." << std::endl;
    } else {
        std::cout << "Student " << name << " not found in the gradebook." << std::endl;
    }
}

// Function to print the entire gradebook
void GradeBook::printGradebook() const {
    std::cout << "Gradebook:" << std::endl;
    for (const auto& entry : gradebookMap) {
        std::cout << entry.first << ": " << entry.second << std::endl;
    }
}
