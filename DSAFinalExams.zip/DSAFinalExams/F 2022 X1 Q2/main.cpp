#include <iostream>
#include "GradeBook.h"

using namespace std;

int main() {
    GradeBook gradebook;
    int choice;
    string name;
    int score;

    do {
        // Print menu
        cout << "\nGradebook Menu:" << endl;
        cout << "1. Insert a new student" << endl;
        cout << "2. Delete a student" << endl;
        cout << "3. Print the entire gradebook" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter student name: ";
                cin >> name;
                cout << "Enter student score: ";
                cin >> score;
                gradebook.insertStudent(name, score);
                break;
            case 2:
                cout << "Enter student name to delete: ";
                cin >> name;
                gradebook.deleteStudent(name);
                break;
            case 3:
                gradebook.printGradebook();
                break;
            case 4:
                cout << "Exiting program." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 4);

    return 0;
}
