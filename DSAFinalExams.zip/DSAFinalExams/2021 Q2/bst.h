// bst.h
#ifndef BST_H
#define BST_H

#include <iostream>

class BST {
private:
    struct Node {
        int data;
        Node* left;
        Node* right;
        Node(int val) : data(val), left(nullptr), right(nullptr) {}
    };
    Node* root;

    void insertRecursive(Node*& root, int val);
    void printKthLargestRecursive(Node* root, int& count, int k);
    void createMirrorRecursive(Node* root);

public:
    BST();
    ~BST();
    void insertElement(int val);
    void printKthLargest(int k);
    void createMirror();
};

#endif

// bst.cpp
#include "bst.h"

BST::BST() : root(nullptr) {}

BST::~BST() {
    // Implement deletion of nodes in BST to free memory
}

void BST::insertRecursive(Node*& root, int val) {
    if (root == nullptr) {
        root = new Node(val);
        return;
    }

    if (val < root->data) {
        insertRecursive(root->left, val);
    } else {
        insertRecursive(root->right, val);
    }
}

void BST::insertElement(int val) {
    insertRecursive(root, val);
}

void BST::printKthLargestRecursive(Node* root, int& count, int k) {
    if (root == nullptr || count >= k) {
        return;
    }

    printKthLargestRecursive(root->right, count, k);

    count++;
    if (count == k) {
        std::cout << "Kth Largest element: " << root->data << std::endl;
        return;
    }

    printKthLargestRecursive(root->left, count, k);
}

void BST::printKthLargest(int k) {
    int count = 0;
    printKthLargestRecursive(root, count, k);
}

void BST::createMirrorRecursive(Node* root) {
    if (root == nullptr) {
        return;
    }

    // Swap left and right children
    Node* temp = root->left;
    root->left = root->right;
    root->right = temp;

    createMirrorRecursive(root->left);
    createMirrorRecursive(root->right);
}

void BST::createMirror() {
    createMirrorRecursive(root);
}

// main.cpp
#include <iostream>
#include "bst.h"

int main() {
    BST bst;
    int choice, val, k;

    do {
        std::cout << "1. Insert Element\n";
        std::cout << "2. Print Kth Largest element\n";
        std::cout << "3. Create Mirror\n";
        std::cout << "4. Quit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter value to insert: ";
                std::cin >> val;
                bst.insertElement(val);
                break;
            case 2:
                std::cout << "Enter k: ";
                std::cin >> k;
                bst.printKthLargest(k);
                break;
            case 3:
                bst.createMirror();
                std::cout << "Mirror created.\n";
                break;
            case 4:
                std::cout << "Exiting program.\n";
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
                break;
        }
    } while (choice != 4);

    return 0;
}
