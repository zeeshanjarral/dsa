#include <iostream>
#include "bst.h"

int main() {
    BST bst;
    int choice, val, k;

    do {
        std::cout << "1. Insert Element\n";
        std::cout << "2. Print Kth Largest element\n";
        std::cout << "3. Create Mirror\n";
        std::cout << "4. Quit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter value to insert: ";
                std::cin >> val;
                bst.insertElement(val);
                break;
            case 2:
                std::cout << "Enter k: ";
                std::cin >> k;
                bst.printKthLargest(k);
                break;
            case 3:
                bst.createMirror();
                std::cout << "Mirror created.\n";
                break;
            case 4:
                std::cout << "Exiting program.\n";
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
                break;
        }
    } while (choice != 4);

    return 0;
}
