// reservation_system.h
#ifndef RESERVATION_SYSTEM_H
#define RESERVATION_SYSTEM_H

#include <iostream>
#include <string>

const int MAX_GUESTS = 100; // Maximum number of guests
const int MAX_RESERVATIONS = 100; // Maximum number of reservations per guest

class ReservationSystem {
private:
    std::string guestNames[MAX_GUESTS];
    int reservations[MAX_GUESTS][MAX_RESERVATIONS];
    int numGuests;

public:
    ReservationSystem(); // Constructor
    void insertReservation(const std::string& guestName, int reservationID);
    void deleteReservation(const std::string& guestName, int reservationID);
    void printAllReservations() const;
};

#endif // RESERVATION_SYSTEM_H
