// reservation_system.cpp
#include "reservation_system.h"

ReservationSystem::ReservationSystem() {
    numGuests = 0;
}

void ReservationSystem::insertReservation(const std::string& guestName, int reservationID) {
    int guestIndex = -1;

    // Check if the guest already exists
    for (int i = 0; i < numGuests; ++i) {
        if (guestNames[i] == guestName) {
            guestIndex = i;
            break;
        }
    }

    // If the guest does not exist, add the guest
    if (guestIndex == -1) {
        if (numGuests < MAX_GUESTS) {
            guestNames[numGuests] = guestName;
            guestIndex = numGuests;
            numGuests++;
        } else {
            std::cout << "Cannot add more guests." << std::endl;
            return;
        }
    }

    // Add the reservation
    for (int i = 0; i < MAX_RESERVATIONS; ++i) {
        if (reservations[guestIndex][i] == 0) {
            reservations[guestIndex][i] = reservationID;
            std::cout << "Reservation ID " << reservationID << " added for guest " << guestName << std::endl;
            return;
        }
    }
    std::cout << "Cannot add more reservations for guest " << guestName << std::endl;
}

void ReservationSystem::deleteReservation(const std::string& guestName, int reservationID) {
    for (int i = 0; i < numGuests; ++i) {
        if (guestNames[i] == guestName) {
            for (int j = 0; j < MAX_RESERVATIONS; ++j) {
                if (reservations[i][j] == reservationID) {
                    reservations[i][j] = 0;
                    std::cout << "Reservation ID " << reservationID << " deleted for guest " << guestName << std::endl;
                    return;
                }
            }
            std::cout << "Reservation ID " << reservationID << " not found for guest " << guestName << std::endl;
            return;
        }
    }
    std::cout << "Guest " << guestName << " not found." << std::endl;
}

void ReservationSystem::printAllReservations() const {
    for (int i = 0; i < numGuests; ++i) {
        std::cout << "Guest: " << guestNames[i] << " Reservations:";
        for (int j = 0; j < MAX_RESERVATIONS; ++j) {
            if (reservations[i][j] != 0) {
                std::cout << " " << reservations[i][j];
            }
        }
        std::cout << std::endl;
    }
}
