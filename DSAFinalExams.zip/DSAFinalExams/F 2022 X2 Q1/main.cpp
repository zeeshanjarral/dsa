// main.cpp
#include <iostream>
#include "reservation_system.h"

int main() {
    ReservationSystem reservationSystem;

    int choice;
    std::string guestName;
    int reservationID;

    do {
        std::cout << "Reservation System Menu:" << std::endl;
        std::cout << "1. Insert a new reservation" << std::endl;
        std::cout << "2. Delete a reservation" << std::endl;
        std::cout << "3. Print all reservations" << std::endl;
        std::cout << "4. Exit" << std::endl;
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter guest name: ";
                std::cin >> guestName;
                std::cout << "Enter reservation ID: ";
                std::cin >> reservationID;
                reservationSystem.insertReservation(guestName, reservationID);
                break;
            case 2:
                std::cout << "Enter guest name: ";
                std::cin >> guestName;
                std::cout << "Enter reservation ID: ";
                std::cin >> reservationID;
                reservationSystem.deleteReservation(guestName, reservationID);
                break;
            case 3:
                std::cout << "All reservations:" << std::endl;
                reservationSystem.printAllReservations();
                break;
            case 4:
                std::cout << "Exiting program." << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please enter a valid option." << std::endl;
        }
    } while (choice != 4);

    return 0;
}
