#include "matrix_linked_list.h"

using namespace std;

Node::Node(int value) : data(value), right(nullptr), down(nullptr) {}

MatrixLinkedList::MatrixLinkedList(int rows, int cols) : rows(rows), cols(cols) {
    head = nullptr;
    Node* temp = nullptr;
    Node* prevRowNode = nullptr;
    Node* prevColNode = nullptr;

    // Create the matrix linked list
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            Node* newNode = new Node(i * cols + j);

            // Link nodes horizontally
            if (prevColNode)
                prevColNode->right = newNode;
            else
                head = newNode;

            prevColNode = newNode;

            // Link nodes vertically
            if (prevRowNode)
                prevRowNode->down = newNode;

            prevRowNode = newNode;
        }
        // Reset the column pointer for the next row
        prevColNode = nullptr;
        prevRowNode = nullptr;
    }
}

MatrixLinkedList::~MatrixLinkedList() {
    Node* current = head;
    while (current != nullptr) {
        Node* nextRow = current->down;
        Node* currentCol = current;

        while (currentCol != nullptr) {
            Node* nextCol = currentCol->right;
            delete currentCol;
            currentCol = nextCol;
        }

        current = nextRow;
    }
}

void MatrixLinkedList::display() {
    Node* currentRow = head;
    while (currentRow != nullptr) {
        Node* currentCol = currentRow;
        while (currentCol != nullptr) {
            cout << currentCol->data << " ";
            currentCol = currentCol->right;
        }
        cout << endl;
        currentRow = currentRow->down;
    }
}
