#ifndef MATRIX_LINKED_LIST_H
#define MATRIX_LINKED_LIST_H

#include <iostream>

class Node {
public:
    int data;
    Node* right;
    Node* down;

    Node(int value);
};

class MatrixLinkedList {
private:
    Node* head;
    int rows;
    int cols;

public:
    MatrixLinkedList(int rows, int cols);
    ~MatrixLinkedList();

    void display();
};

#endif // MATRIX_LINKED_LIST_H
