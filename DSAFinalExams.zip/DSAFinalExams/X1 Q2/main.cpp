#include <iostream>
#include "course.h"

using namespace std;

int main() {
    CourseManager courseManager;
    int choice, code;

    do {
        cout << "\nMenu:\n";
        cout << "1. Add new course code\n";
        cout << "2. Display all course codes (pre-order traversal)\n";
        cout << "3. Search for a course code\n";
        cout << "4. Display smallest course code\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                cout << "Enter course code: ";
                cin >> code;
                courseManager.addCourse(code);
                break;
            case 2:
                courseManager.displayPreOrder(courseManager.getRoot());
                break;
            case 3:
                cout << "Enter course code to search: ";
                cin >> code;
                if (courseManager.searchCourse(code)) {
                    cout << "Course code " << code << " is found.\n";
                } else {
                    cout << "Course code " << code << " is not found.\n";
                }
                break;
            case 4:
                if (courseManager.findSmallestCourse() == -1) {
                    cout << "No course codes available.\n";
                } else {
                    cout << "Smallest course code: " << courseManager.findSmallestCourse() << endl;
                }
                break;
            case 5:
                cout << "Exiting program...\n";
                break;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while(choice != 5);

    return 0;
}
