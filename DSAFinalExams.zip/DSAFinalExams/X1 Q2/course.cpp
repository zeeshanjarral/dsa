#include "course.h"
#include <iostream>

CourseManager::CourseManager() : root(nullptr) {}

CourseManager::~CourseManager() {
    // TODO: Implement deletion of tree nodes
}

void insertNode(TreeNode*& node, int code) {
    if (node == nullptr) {
        node = new TreeNode(code);
    } else {
        if (code < node->courseCode) {
            insertNode(node->left, code);
        } else {
            insertNode(node->right, code);
        }
    }
}

void CourseManager::addCourse(int code) {
    insertNode(root, code);
}

void preOrderTraversal(TreeNode* node) {
    if (node != nullptr) {
        std::cout << node->courseCode << " ";
        preOrderTraversal(node->left);
        preOrderTraversal(node->right);
    }
}

void CourseManager::displayPreOrder(TreeNode* node) {
    std::cout << "Course codes in pre-order traversal: ";
    preOrderTraversal(node);
    std::cout << std::endl;
}

bool searchNode(TreeNode* node, int code) {
    if (node == nullptr) {
        return false;
    }
    if (node->courseCode == code) {
        return true;
    } else if (code < node->courseCode) {
        return searchNode(node->left, code);
    } else {
        return searchNode(node->right, code);
    }
}

bool CourseManager::searchCourse(int code) {
    return searchNode(root, code);
}

int findMinValue(TreeNode* node) {
    TreeNode* current = node;
    while (current->left != nullptr) {
        current = current->left;
    }
    return current->courseCode;
}

int CourseManager::findSmallestCourse() {
    if (root == nullptr) {
        return -1; // Indicates tree is empty
    }
    return findMinValue(root);
}
