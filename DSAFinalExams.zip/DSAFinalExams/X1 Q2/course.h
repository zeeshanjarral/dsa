#ifndef COURSE_H
#define COURSE_H

class TreeNode {
public:
    int courseCode;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int code) : courseCode(code), left(nullptr), right(nullptr) {}
};

class CourseManager {
private:
    TreeNode* root;

public:
    CourseManager();
    ~CourseManager();
    void addCourse(int code);
    void displayPreOrder(TreeNode* node);
    bool searchCourse(int code);
    int findSmallestCourse();
};

#endif // COURSE_H
