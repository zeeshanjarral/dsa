#ifndef LIBRARY_H
#define LIBRARY_H

class TreeNode {
public:
    int bookCode;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int code) : bookCode(code), left(nullptr), right(nullptr) {}
};

class LibraryManager {
private:
    TreeNode* root;

public:
    LibraryManager();
    ~LibraryManager();
    void addBook(int code);
    void displayPostOrder(TreeNode* node);
    bool searchBook(int code);
    int findHighestBook();
};

#endif // LIBRARY_H
