#include <iostream>
#include "library.h"

using namespace std;

int main() {
    LibraryManager libraryManager;
    int choice, code;

    do {
        cout << "\nMenu:\n";
        cout << "1. Add new book code\n";
        cout << "2. Display all book codes (post-order traversal)\n";
        cout << "3. Search for a book code\n";
        cout << "4. Display highest book code\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                cout << "Enter book code: ";
                cin >> code;
                libraryManager.addBook(code);
                break;
            case 2:
                libraryManager.displayPostOrder(libraryManager.getRoot());
                break;
            case 3:
                cout << "Enter book code to search: ";
                cin >> code;
                if (libraryManager.searchBook(code)) {
                    cout << "Book code " << code << " is found.\n";
                } else {
                    cout << "Book code " << code << " is not found.\n";
                }
                break;
            case 4:
                if (libraryManager.findHighestBook() == -1) {
                    cout << "No book codes available.\n";
                } else {
                    cout << "Highest book code: " << libraryManager.findHighestBook() << endl;
                }
                break;
            case 5:
                cout << "Exiting program...\n";
                break;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while(choice != 5);

    return 0;
}
