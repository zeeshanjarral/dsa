#include "library.h"
#include <iostream>

LibraryManager::LibraryManager() : root(nullptr) {}

LibraryManager::~LibraryManager() {
    // TODO: Implement deletion of tree nodes
}

void insertNode(TreeNode*& node, int code) {
    if (node == nullptr) {
        node = new TreeNode(code);
    } else {
        if (code < node->bookCode) {
            insertNode(node->left, code);
        } else {
            insertNode(node->right, code);
        }
    }
}

void LibraryManager::addBook(int code) {
    insertNode(root, code);
}

void postOrderTraversal(TreeNode* node) {
    if (node != nullptr) {
        postOrderTraversal(node->left);
        postOrderTraversal(node->right);
        std::cout << node->bookCode << " ";
    }
}

void LibraryManager::displayPostOrder(TreeNode* node) {
    std::cout << "Book codes in post-order traversal: ";
    postOrderTraversal(node);
    std::cout << std::endl;
}

bool searchNode(TreeNode* node, int code) {
    if (node == nullptr) {
        return false;
    }
    if (node->bookCode == code) {
        return true;
    } else if (code < node->bookCode) {
        return searchNode(node->left, code);
    } else {
        return searchNode(node->right, code);
    }
}

bool LibraryManager::searchBook(int code) {
    return searchNode(root, code);
}

int findMaxValue(TreeNode* node) {
    TreeNode* current = node;
    while (current->right != nullptr) {
        current = current->right;
    }
    return current->bookCode;
}

int LibraryManager::findHighestBook() {
    if (root == nullptr) {
        return -1; // Indicates tree is empty
    }
    return findMaxValue(root);
}
