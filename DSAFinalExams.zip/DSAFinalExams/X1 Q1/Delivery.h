#ifndef DELIVERY_H
#define DELIVERY_H

#include <iostream>
#include <unordered_map>

class DeliveryService {
private:
    std::unordered_map<int, std::string> parcelMap;

public:
    void insertCourier(int trackingNumber, const std::string& courierName);
    void deleteCourier(int trackingNumber);
    void printAllCouriers();
};

#endif // DELIVERY_H
