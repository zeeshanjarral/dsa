#include "delivery.h"

void DeliveryService::insertCourier(int trackingNumber, const std::string& courierName) {
    parcelMap[trackingNumber] = courierName;
}

void DeliveryService::deleteCourier(int trackingNumber) {
    parcelMap.erase(trackingNumber);
}

void DeliveryService::printAllCouriers() {
    std::cout << "Tracking Number\tCourier Name\n";
    for (const auto& entry : parcelMap) {
        std::cout << entry.first << "\t\t" << entry.second << std::endl;
    }
}
