#include <iostream>
#include "delivery.h"

using namespace std;

int main() {
    DeliveryService deliveryService;
    int choice, trackingNumber;
    string courierName;

    do {
        cout << "\nMenu:\n";
        cout << "1. Insert a new courier\n";
        cout << "2. Delete a courier\n";
        cout << "3. Print all couriers\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                cout << "Enter tracking number: ";
                cin >> trackingNumber;
                cout << "Enter courier name: ";
                cin >> courierName;
                deliveryService.insertCourier(trackingNumber, courierName);
                break;
            case 2:
                cout << "Enter tracking number to delete: ";
                cin >> trackingNumber;
                deliveryService.deleteCourier(trackingNumber);
                break;
            case 3:
                deliveryService.printAllCouriers();
                break;
            case 4:
                cout << "Exiting program...\n";
                break;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    } while(choice != 4);

    return 0;
}
