#ifndef CAR_RENTAL_SYSTEM_H
#define CAR_RENTAL_SYSTEM_H

#include <iostream>

// Define the structure of a node in the binary search tree
struct TreeNode {
    int data;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int val) : data(val), left(nullptr), right(nullptr) {}
};

// Class for the car rental system
class CarRentalSystem {
private:
    TreeNode* root;

    // Helper functions for the binary search tree operations
    void insertHelper(TreeNode*& node, int value);
    bool searchHelper(TreeNode* node, int value);
    void displayDescendingHelper(TreeNode* node);

public:
    // Constructor
    CarRentalSystem();

    // Destructor
    ~CarRentalSystem();

    // Function to add a new car ID to the fleet
    void addCarID(int carID);

    // Function to search for a specific car by its ID
    bool searchCarID(int carID);

    // Function to display all car IDs in descending order
    void displayCarIDsDescending();
};

#endif
