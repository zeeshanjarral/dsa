#include <iostream>
#include "CarRentalSystem.h"

using namespace std;

int main() {
    CarRentalSystem carSystem;

    // Adding some sample car IDs
    carSystem.addCarID(10);
    carSystem.addCarID(5);
    carSystem.addCarID(15);
    carSystem.addCarID(3);
    carSystem.addCarID(8);

    // Search for a specific car ID
    int searchID = 5;
    cout << "Searching for car ID " << searchID << ": ";
    if (carSystem.searchCarID(searchID)) {
        cout << "Found!" << endl;
    } else {
        cout << "Not found!" << endl;
    }

    // Display all car IDs in descending order
    cout << "Car IDs in descending order: ";
    carSystem.displayCarIDsDescending();
    cout << endl;

    return 0;
}
