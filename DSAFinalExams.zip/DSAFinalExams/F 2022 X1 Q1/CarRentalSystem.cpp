#include "CarRentalSystem.h"

// Constructor
CarRentalSystem::CarRentalSystem() {
    root = nullptr;
}

// Destructor
CarRentalSystem::~CarRentalSystem() {
    // To be implemented
}

// Function to add a new car ID to the fleet
void CarRentalSystem::addCarID(int carID) {
    insertHelper(root, carID);
}

// Helper function to insert a new car ID into the binary search tree
void CarRentalSystem::insertHelper(TreeNode*& node, int value) {
    if (node == nullptr) {
        node = new TreeNode(value);
    } else {
        if (value < node->data) {
            insertHelper(node->left, value);
        } else {
            insertHelper(node->right, value);
        }
    }
}

// Function to search for a specific car by its ID
bool CarRentalSystem::searchCarID(int carID) {
    return searchHelper(root, carID);
}

// Helper function to search for a car ID in the binary search tree
bool CarRentalSystem::searchHelper(TreeNode* node, int value) {
    if (node == nullptr) {
        return false;
    } else if (node->data == value) {
        return true;
    } else if (value < node->data) {
        return searchHelper(node->left, value);
    } else {
        return searchHelper(node->right, value);
    }
}

// Function to display all car IDs in descending order
void CarRentalSystem::displayCarIDsDescending() {
    displayDescendingHelper(root);
}

// Helper function to display car IDs in descending order using reverse inorder traversal
void CarRentalSystem::displayDescendingHelper(TreeNode* node) {
    if (node != nullptr) {
        displayDescendingHelper(node->right);
        std::cout << node->data << " ";
        displayDescendingHelper(node->left);
    }
}
